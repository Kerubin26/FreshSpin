using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using FreshSpinApi.Data;
using FreshSpinApi.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace FreshSpinApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly FreshSpinDbContext _context;
    private readonly IConfiguration _config;
    private readonly PasswordHasher<AppUser> _hasher;

    public AuthController(FreshSpinDbContext context, IConfiguration config, PasswordHasher<AppUser> hasher)
    {
        _context = context;
        _config = config;
        _hasher = hasher;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var username = request.Username.Trim().ToLowerInvariant();
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);

        // Keep the response generic so the login page does not reveal whether an account exists.
        if (user == null)
            return Unauthorized(new { message = "Incorrect username/email or password.", attemptsRemaining = 2 });

        if (user.LockoutEndUtc.HasValue && user.LockoutEndUtc.Value > DateTime.UtcNow)
        {
            var retryAfter = Math.Max(1, (int)Math.Ceiling((user.LockoutEndUtc.Value - DateTime.UtcNow).TotalSeconds));
            Response.Headers.RetryAfter = retryAfter.ToString();
            return StatusCode(429, new
            {
                message = $"Too many unsuccessful login attempts. Please wait {retryAfter} seconds.",
                retryAfterSeconds = retryAfter
            });
        }

        // Expired lockouts start with a clean counter.
        if (user.LockoutEndUtc.HasValue && user.LockoutEndUtc.Value <= DateTime.UtcNow)
        {
            user.LockoutEndUtc = null;
            user.FailedLoginAttempts = 0;
            await _context.SaveChangesAsync();
        }

        var passwordResult = _hasher.VerifyHashedPassword(user, user.PasswordHash, request.Password);
        if (passwordResult == PasswordVerificationResult.Failed)
        {
            user.FailedLoginAttempts++;

            if (user.FailedLoginAttempts >= 3)
            {
                user.LockoutEndUtc = DateTime.UtcNow.AddSeconds(30);
                await _context.SaveChangesAsync();

                Response.Headers.RetryAfter = "30";
                return StatusCode(429, new
                {
                    message = "Too many unsuccessful login attempts. Please wait 30 seconds.",
                    retryAfterSeconds = 30
                });
            }

            var remaining = 3 - user.FailedLoginAttempts;
            await _context.SaveChangesAsync();
            return Unauthorized(new
            {
                message = "Incorrect username/email or password.",
                attemptsRemaining = remaining
            });
        }

        // Successful authentication clears failed attempts.
        user.FailedLoginAttempts = 0;
        user.LockoutEndUtc = null;
        await _context.SaveChangesAsync();

        return Ok(CreateLoginResponse(user));
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        var username = request.Username.Trim().ToLowerInvariant();
        if (await _context.Users.AnyAsync(u => u.Username == username))
            return Conflict(new { message = "Username is already registered." });

        var nextNumber = await _context.Users.CountAsync(u => u.Role == "Customer") + 1;
        string customerId;
        do
        {
            customerId = $"CUST-{nextNumber:000}";
            nextNumber++;
        } while (await _context.Users.AnyAsync(u => u.UserId == customerId));

        var user = new AppUser
        {
            UserId = customerId,
            FullName = request.FullName.Trim(),
            Username = username,
            Role = "Customer"
        };
        user.PasswordHash = _hasher.HashPassword(user, request.Password);

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok(CreateLoginResponse(user));
    }

    private LoginResponse CreateLoginResponse(AppUser user)
    {
        var expiry = DateTime.UtcNow.AddMinutes(_config.GetValue<int>("Jwt:ExpiryMinutes", 120));
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.UserId),
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.GivenName, user.FullName),
            new Claim(ClaimTypes.Role, user.Role)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
        var token = new JwtSecurityToken(
            issuer: _config["Jwt:Issuer"],
            audience: _config["Jwt:Audience"],
            claims: claims,
            expires: expiry,
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)
        );

        return new LoginResponse
        {
            Token = new JwtSecurityTokenHandler().WriteToken(token),
            UserId = user.UserId,
            FullName = user.FullName,
            Username = user.Username,
            Role = user.Role,
            ExpiresAt = expiry
        };
    }
}
