using System.Security.Claims;
using FreshSpinApi.Data;
using FreshSpinApi.Models;
using FreshSpinApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FreshSpinApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class BookingsController : ControllerBase
{
    private readonly FreshSpinDbContext _context;
    private readonly IAuditService _auditService;

    public BookingsController(FreshSpinDbContext context, IAuditService auditService)
    {
        _context = context;
        _auditService = auditService;
    }

    private string UserId => User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "";
    private string UserRole => User.FindFirstValue(ClaimTypes.Role) ?? "";

    [HttpGet]
    public async Task<IActionResult> GetBookings()
    {
        var query = _context.Bookings.AsQueryable();

        if (User.IsInRole("Customer"))
            query = query.Where(b => b.CustomerId == UserId);

        return Ok(await query.OrderByDescending(b => b.CreatedAt).ToListAsync());
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetBookingById(int id)
    {
        var booking = await _context.Bookings.FindAsync(id);
        if (booking == null) return NotFound();

        if (User.IsInRole("Customer") && booking.CustomerId != UserId)
            return Forbid();

        return Ok(booking);
    }

    [HttpPost]
    [Authorize(Roles = "Customer")]
    public async Task<IActionResult> CreateBooking(CreateBookingRequest request)
    {
        var serviceType = request.ServiceType.Trim();
        decimal totalCost;
        double savedWeight = request.WeightKg;
        string savedServiceType = serviceType;

        if (serviceType == "Wash & Fold")
        {
            if (request.WeightKg <= 0)
                return BadRequest(new { message = "Weight is required for Wash & Fold." });
            totalCost = Math.Round((decimal)request.WeightKg * 35m, 2);
        }
        else if (serviceType == "Steam Iron")
        {
            if (request.WeightKg <= 0)
                return BadRequest(new { message = "Weight is required for Steam Iron." });
            totalCost = Math.Round((decimal)request.WeightKg * 25m, 2);
        }
        else if (serviceType == "Dry Cleaning")
        {
            var garmentPrices = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase)
            {
                ["Dress Shirt / Polo"] = 250m,
                ["Pants / Slacks"] = 255m,
                ["Suit Jacket / Blazer"] = 335m,
                ["Two-Piece Suit"] = 590m,
                ["Barong Tagalog (Jusi/Pina)"] = 250m,
                ["Casual Dress"] = 300m,
                ["Winter / Wool Coat"] = 455m,
                ["Evening Gown"] = 800m,
                ["Wedding Gown"] = 1800m
            };

            if (string.IsNullOrWhiteSpace(request.GarmentType) ||
                !garmentPrices.TryGetValue(request.GarmentType, out var garmentPrice))
                return BadRequest(new { message = "Please select a valid dry-cleaning garment type." });

            if (request.Quantity <= 0)
                return BadRequest(new { message = "Quantity must be at least 1 for Dry Cleaning." });

            totalCost = garmentPrice * request.Quantity;
            savedWeight = 0;
            savedServiceType = $"Dry Cleaning - {request.GarmentType} x{request.Quantity}";
        }
        else
        {
            return BadRequest(new { message = "Invalid service type." });
        }

        var booking = new Booking
        {
            CustomerId = UserId,
            ServiceType = savedServiceType,
            WeightKg = savedWeight,
            TotalCost = totalCost,
            PickupAddress = request.PickupAddress.Trim(),
            Status = BookingStatus.Pending,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _context.Bookings.Add(booking);
        await _context.SaveChangesAsync();
        await _auditService.LogActionAsync("BOOKING_CREATED", UserRole, UserId, booking.Id,
            $"New laundry booking created for service: {booking.ServiceType}");

        return CreatedAtAction(nameof(GetBookingById), new { id = booking.Id }, booking);
    }

    [HttpPut("{id:int}/assign")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> AssignRider(int id, AssignRiderRequest request)
    {
        var booking = await _context.Bookings.FindAsync(id);
        if (booking == null) return NotFound();

        booking.AssignedRiderId = request.RiderId.Trim();
        booking.Status = BookingStatus.Assigned;
        booking.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        await _auditService.LogActionAsync("RIDER_ASSIGNED", UserRole, UserId, booking.Id,
            $"Assigned Rider {booking.AssignedRiderId} to Booking #{id}");

        return Ok(booking);
    }

    [HttpPut("{id:int}/status")]
    [Authorize(Roles = "Admin,Staff")]
    public async Task<IActionResult> UpdateStatus(int id, UpdateStatusRequest request)
    {
        var booking = await _context.Bookings.FindAsync(id);
        if (booking == null) return NotFound();

        var oldStatus = booking.Status;
        booking.Status = request.Status;
        booking.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        await _auditService.LogActionAsync("STATUS_UPDATED", UserRole, UserId, booking.Id,
            $"Status changed from {oldStatus} to {request.Status}");

        return Ok(booking);
    }

    [HttpGet("audit-logs")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetAuditLogs()
    {
        return Ok(await _context.AuditLogs.OrderByDescending(l => l.Timestamp).ToListAsync());
    }
}
