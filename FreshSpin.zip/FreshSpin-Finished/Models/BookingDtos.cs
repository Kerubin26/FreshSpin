using System.ComponentModel.DataAnnotations;

namespace FreshSpinApi.Models;

public class CreateBookingRequest
{
    [Required]
    public string ServiceType { get; set; } = string.Empty;

    // Used by Wash & Fold and Steam Iron.
    // Dry Cleaning uses garment type + quantity instead.
    [Range(0, 1000)]
    public double WeightKg { get; set; }

    // Used only for Dry Cleaning.
    public string? GarmentType { get; set; }

    // Used only for Dry Cleaning.
    [Range(0, 100)]
    public int Quantity { get; set; }

    [Required]
    public string PickupAddress { get; set; } = string.Empty;
}

public class AssignRiderRequest
{
    [Required]
    public string RiderId { get; set; } = string.Empty;
}

public class UpdateStatusRequest
{
    public BookingStatus Status { get; set; }
}
