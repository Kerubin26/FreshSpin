using FreshSpinApi.Models;
using Microsoft.EntityFrameworkCore;

namespace FreshSpinApi.Data;

public class FreshSpinDbContext : DbContext
{
    public FreshSpinDbContext(DbContextOptions<FreshSpinDbContext> options) : base(options) { }

    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<AppUser> Users => Set<AppUser>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<AppUser>().HasIndex(u => u.Username).IsUnique();
        modelBuilder.Entity<AppUser>().HasIndex(u => u.UserId).IsUnique();
    }
}
