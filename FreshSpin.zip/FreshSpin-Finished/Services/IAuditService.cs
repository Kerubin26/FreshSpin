using FreshSpinApi.Data;
using FreshSpinApi.Models;

namespace FreshSpinApi.Services;

public interface IAuditService
{
    Task LogActionAsync(string action, string role, string userId, int entityId, string details);
}

public class AuditService : IAuditService
{
    private readonly FreshSpinDbContext _context;

    public AuditService(FreshSpinDbContext context) => _context = context;

    public async Task LogActionAsync(string action, string role, string userId, int entityId, string details)
    {
        _context.AuditLogs.Add(new AuditLog
        {
            Action = action,
            PerformedByRole = role,
            PerformedById = userId,
            RelatedEntityId = entityId,
            Details = details,
            Timestamp = DateTime.UtcNow
        });
        await _context.SaveChangesAsync();
    }
}
